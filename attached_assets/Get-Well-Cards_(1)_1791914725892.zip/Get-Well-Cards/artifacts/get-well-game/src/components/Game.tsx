import { useCallback, useEffect, useRef, useState, type PointerEvent } from 'react';
import { ArrowLeft, ArrowRight, Play, RotateCcw, Sparkles } from 'lucide-react';
import { useFeedback } from '../hooks/useFeedback';

type GameItem = { id: number; x: number; y: number; icon: string; type: 'good' | 'hazard' };
type GameProps = { soundOn: boolean; onConfetti: () => void };

const goodItems = [
  { icon: '🥤', points: 20, feedback: 'Monster Energy Health +20!' },
  { icon: '💕', points: 10, feedback: 'MM2 Victory Royale!' },
  { icon: '🍵', points: 15, feedback: 'Zizi is cheering for you!' },
  { icon: '🐱', points: 25, feedback: 'Bablu gives you a purr-fect hug!' },
];

export function Game({ soundOn, onConfetti }: GameProps) {
  const [playing, setPlaying] = useState(false);
  const [score, setScore] = useState(0);
  const [lives, setLives] = useState(3);
  const [feedback, setFeedback] = useState('');
  const [feedbackKey, setFeedbackKey] = useState(0);
  const [round, setRound] = useState(0);
  const arenaRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const dimensionsRef = useRef({ width: 0, height: 0, dpr: 1 });
  const itemsRef = useRef<GameItem[]>([]);
  const playerXRef = useRef(.5);
  const scoreRef = useRef(0);
  const livesRef = useRef(3);
  const playingRef = useRef(false);
  const roundRef = useRef(round);
  const { tap } = useFeedback(soundOn);
  const tapRef = useRef(tap);
  const confettiRef = useRef(onConfetti);
  tapRef.current = tap;
  confettiRef.current = onConfetti;

  useEffect(() => {
    const canvas = canvasRef.current;
    const arena = arenaRef.current;
    if (!canvas || !arena) return;
    const resize = () => {
      const bounds = arena.getBoundingClientRect();
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      dimensionsRef.current = { width: bounds.width, height: bounds.height, dpr };
      canvas.width = Math.round(bounds.width * dpr);
      canvas.height = Math.round(bounds.height * dpr);
      const context = canvas.getContext('2d');
      if (context) context.setTransform(dpr, 0, 0, dpr, 0, 0);
    };
    resize();
    const observer = new ResizeObserver(resize);
    observer.observe(arena);
    return () => observer.disconnect();
  }, []);

  const finishGame = useCallback(() => {
    playingRef.current = false;
    setPlaying(false);
    itemsRef.current = [];
  }, []);

  const announce = useCallback((text: string) => {
    setFeedback(text);
    setFeedbackKey((value) => value + 1);
  }, []);

  const handleItem = useCallback((item: GameItem) => {
    if (!playingRef.current) return;
    itemsRef.current = itemsRef.current.filter((candidate) => candidate.id !== item.id);
    if (item.type === 'hazard') {
      tapRef.current(250);
      announce('Evade the fever cloud!');
      livesRef.current = Math.max(0, livesRef.current - 1);
      setLives(livesRef.current);
      if (livesRef.current <= 0) finishGame();
      return;
    }
    const prize = goodItems.find((entry) => entry.icon === item.icon) ?? goodItems[0];
    scoreRef.current += prize.points;
    setScore(scoreRef.current);
    announce(prize.feedback);
    tapRef.current(710);
    if (scoreRef.current >= 100) {
      announce('Zizi is cheering for you!');
      finishGame();
      confettiRef.current();
    }
  }, [announce, finishGame]);

  const startGame = () => {
    scoreRef.current = 0;
    livesRef.current = 3;
    playerXRef.current = .5;
    itemsRef.current = [];
    setScore(0);
    setLives(3);
    setFeedback('');
    playingRef.current = true;
    setPlaying(true);
    roundRef.current += 1;
    setRound(roundRef.current);
    tap(740);
  };

  useEffect(() => {
    if (!playing) return;
    let frame = 0;
    let lastTime = 0;
    let spawnElapsed = 0;
    let uiElapsed = 0;
    let nextId = 0;
    const draw = (timestamp: number) => {
      const { width, height } = dimensionsRef.current;
      const canvas = canvasRef.current;
      const context = canvas?.getContext('2d');
      if (!context || !width || !height) {
        frame = requestAnimationFrame(draw);
        return;
      }
      const delta = Math.min((timestamp - (lastTime || timestamp)) / 1000, .04);
      lastTime = timestamp;
      const items = itemsRef.current;
      spawnElapsed += delta;
      uiElapsed += delta;
      if (spawnElapsed >= .86) {
        spawnElapsed = 0;
        const hazard = Math.random() < .25;
        const prize = goodItems[Math.floor(Math.random() * goodItems.length)];
        items.push({ id: nextId++, x: .08 + Math.random() * .84, y: -.04, icon: hazard ? '🤒' : prize.icon, type: hazard ? 'hazard' : 'good' });
      }

      context.clearRect(0, 0, width, height);
      items.forEach((item) => {
        item.y += delta * (item.type === 'hazard' ? .37 : .33);
        const x = item.x * width;
        const y = item.y * height;
        if (item.y > .76 && item.y < .91 && Math.abs(item.x - playerXRef.current) < .105) {
          item.y = 2;
          handleItem(item);
          return;
        }
        if (item.y >= 1.03) {
          if (item.type === 'hazard' && playingRef.current) {
            livesRef.current = Math.max(0, livesRef.current - 1);
            setLives(livesRef.current);
            tapRef.current(220);
            announce('Evade the fever cloud!');
            if (livesRef.current <= 0) finishGame();
          }
          return;
        }
        context.save();
        context.shadowColor = item.type === 'hazard' ? 'rgba(20,10,25,.35)' : 'rgba(255,195,222,.35)';
        context.shadowBlur = 11;
        context.font = `${Math.round(Math.max(25, Math.min(38, width * .075)))}px "Apple Color Emoji","Segoe UI Emoji",sans-serif`;
        context.textAlign = 'center';
        context.textBaseline = 'middle';
        context.fillText(item.icon, x, y);
        context.restore();
      });
      itemsRef.current = items.filter((item) => item.y < 1.03);
      const px = playerXRef.current * width;
      const py = height * .84;
      context.save();
      context.shadowColor = 'rgba(13,7,19,.4)';
      context.shadowBlur = 11;
      context.shadowOffsetY = 5;
      context.fillStyle = '#f58bb7';
      context.strokeStyle = '#ffd8e8';
      context.lineWidth = 3;
      context.beginPath();
      context.roundRect(px - 31, py - 24, 62, 47, 15);
      context.fill();
      context.stroke();
      context.shadowColor = 'transparent';
      context.font = '25px "Apple Color Emoji","Segoe UI Emoji",sans-serif';
      context.textAlign = 'center';
      context.textBaseline = 'middle';
      context.fillText('🐸', px, py - 1);
      context.restore();
      if (uiElapsed > .5) uiElapsed = 0;
      if (playingRef.current) frame = requestAnimationFrame(draw);
    };
    frame = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(frame);
  }, [finishGame, handleItem, playing, round, announce]);

  useEffect(() => {
    if (!playing) return;
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key !== 'ArrowLeft' && event.key !== 'ArrowRight' && event.key !== 'a' && event.key !== 'd') return;
      event.preventDefault();
      const direction = event.key === 'ArrowLeft' || event.key === 'a' ? -1 : 1;
      playerXRef.current = Math.max(.08, Math.min(.92, playerXRef.current + direction * .075));
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [playing]);

  const movePlayer = (event: PointerEvent<HTMLDivElement>) => {
    if (!playing || !arenaRef.current) return;
    const bounds = arenaRef.current.getBoundingClientRect();
    playerXRef.current = Math.max(.08, Math.min(.92, (event.clientX - bounds.left) / bounds.width));
  };

  const moveBy = (direction: number) => {
    playerXRef.current = Math.max(.08, Math.min(.92, playerXRef.current + direction * .09));
    tap(560);
  };

  const status = score >= 100 ? 'BOOST COMPLETE' : playing ? 'ROUND IN PROGRESS' : score > 0 ? 'ROUND PAUSED' : 'READY WHEN YOU ARE';
  return (
    <section className="panel game-panel tilt-surface" aria-labelledby="game-title">
      <div className="section-heading">
        <div>
          <div className="eyebrow"><Sparkles size={12} /> MINI GAME · EVADE MODE</div>
          <h2 id="game-title">Evade the Fever &amp; Catch the Monster Energy</h2>
          <p>Drag your little pink catcher. Grab the good stuff, dodge the fever clouds.</p>
        </div>
        <div className="score-pill" data-testid="status-game-score"><small>Score</small><strong>{score}</strong></div>
      </div>
      <div
        className="game-arena"
        ref={arenaRef}
        onPointerMove={movePlayer}
        onPointerDown={(event) => {
          movePlayer(event);
          if (event.pointerType !== 'mouse') event.currentTarget.setPointerCapture(event.pointerId);
        }}
        aria-label="Game arena. Move your finger to catch falling treats and avoid clouds."
        tabIndex={0}
        data-testid="game-arena"
      >
        <canvas className="game-canvas" ref={canvasRef} aria-hidden="true" />
        <div className="arena-hud"><span>{status}</span><span>♥ {playing ? lives : 3} / 3</span></div>
        {feedback && <div key={feedbackKey} className="float-feedback" aria-live="polite">{feedback}</div>}
        {!playing && (
          <div className="arena-start">
            <div className="big-emoji">{score >= 100 ? '🏆' : score > 0 && lives <= 0 ? '🌤️' : '🎮'}</div>
            <strong>{score >= 100 ? 'You powered through!' : score > 0 && lives <= 0 ? 'Fever cloud got you!' : 'Ready, Cute Monster?'}</strong>
            <span>{score >= 100 ? '100 health points collected. Rest is your next level.' : 'Collect 100 points to win. Three fever clouds and the round is over.'}</span>
          </div>
        )}
      </div>
      <div className="game-controls">
        <span className="control-hint">Catch 🥤 +20 · 💕 +10 · 🍵 +15 · 🐱 +25<br />Avoid 🤒 clouds · {lives} hearts left</span>
        <div className="keyboard-controls" aria-label="Move catcher">
          <button className="move-button tilt-surface" onClick={() => moveBy(-1)} aria-label="Move catcher left" data-testid="button-move-left"><ArrowLeft size={17} /></button>
          <button className="move-button tilt-surface" onClick={() => moveBy(1)} aria-label="Move catcher right" data-testid="button-move-right"><ArrowRight size={17} /></button>
        </div>
        <button className="primary-button tilt-surface" onClick={startGame} data-testid="button-start-game">
          {score > 0 || lives < 3 ? <RotateCcw size={16} /> : <Play size={16} />}
          {playing ? 'Restart round' : score >= 100 ? 'Play again' : 'Start game'}
        </button>
      </div>
    </section>
  );
}
