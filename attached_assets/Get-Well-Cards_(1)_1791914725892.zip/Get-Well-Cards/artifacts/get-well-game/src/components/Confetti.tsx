import { useEffect, useState } from 'react';

type ConfettiProps = {
  trigger: number;
};

const colors = ['#f28bb5', '#c7a7ed', '#f5d276', '#a3dabb', '#ffb8ca', '#fff0b3'];

export function Confetti({ trigger }: ConfettiProps) {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    if (!trigger) return;
    setVisible(true);
    const timer = window.setTimeout(() => setVisible(false), 2100);
    return () => window.clearTimeout(timer);
  }, [trigger]);

  if (!visible) return null;

  return (
    <div className="confetti" aria-hidden="true">
      {Array.from({ length: 44 }, (_, index) => (
        <i
          key={`${trigger}-${index}`}
          style={{
            left: `${(index * 37 + 7) % 100}%`,
            background: colors[index % colors.length],
            animationDelay: `${(index % 9) * 0.045}s`,
            transform: `rotate(${index * 23}deg)`,
          }}
        />
      ))}
    </div>
  );
}
