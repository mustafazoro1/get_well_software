import { useState, type CSSProperties } from 'react';
import { Heart, Sparkles } from 'lucide-react';
import { useFeedback } from '../hooks/useFeedback';
import { Confetti } from './Confetti';

type SupportFeaturesProps = {
  soundOn: boolean;
};

export function SupportFeatures({ soundOn }: SupportFeaturesProps) {
  const [hearts, setHearts] = useState<number[]>([]);
  const [babluReacts, setBabluReacts] = useState(false);
  const [chestState, setChestState] = useState<'closed' | 'shaking' | 'open'>('closed');
  const [confettiTrigger, setConfettiTrigger] = useState(0);
  const { tap, meow } = useFeedback(soundOn);

  const petBablu = () => {
    const id = Date.now();
    setHearts((current) => [...current.slice(-7), id]);
    setBabluReacts(true);
    window.setTimeout(() => setHearts((current) => current.filter((heart) => heart !== id)), 1500);
    window.setTimeout(() => setBabluReacts(false), 520);
    tap(560);
    meow();
  };

  const openChest = () => {
    if (chestState === 'shaking') return;
    if (chestState === 'open') {
      setChestState('closed');
      return;
    }
    tap(520);
    setChestState('shaking');
    window.setTimeout(() => {
      setChestState('open');
      setConfettiTrigger((value) => value + 1);
      tap(820);
    }, 520);
  };

  return (
    <>
      <div className="support-grid">
        <section className="panel support-card cat-card tilt-surface" aria-labelledby="bablu-title">
          <div className="support-kicker">COMPANION BUFF · ALWAYS AVAILABLE</div>
          <h2 id="bablu-title">Bablu's cozy corner</h2>
          <button className={`cat-button tilt-surface ${babluReacts ? 'meowing' : ''}`} onClick={petBablu} aria-label="Tap Bablu for a purr-fect hug" data-testid="button-pet-bablu">
            <span className="cat-avatar" aria-hidden="true">🐱</span>
            <span className="cat-copy">
              <strong>Give Bablu a little tap</strong>
              <small>{hearts.length ? 'Bablu is sending love right back.' : 'A tiny purr break for your health bar.'}</small>
            </span>
            <Heart size={18} fill="currentColor" />
          </button>
          {hearts.map((heart, index) => (
            <span className="heart-pop" key={heart} style={{ '--heart-x': `${33 + (index % 5) * 11}%` } as CSSProperties} aria-hidden="true">♥</span>
          ))}
        </section>

        <section className="panel support-card loot-card tilt-surface" aria-labelledby="loot-title">
          <div className="support-kicker">A LITTLE SURPRISE FROM ZIZI</div>
          <h2 id="loot-title">Unbox Care Package</h2>
          <p>One tap to open a tiny care drop. No grinding required.</p>
          <button
            className={`chest-button tilt-surface ${chestState === 'open' ? 'open' : ''} ${chestState === 'shaking' ? 'shaking' : ''}`}
            onClick={openChest}
            aria-label={chestState === 'open' ? 'Close care package chest' : 'Unbox Care Package'}
            aria-expanded={chestState === 'open'}
            data-testid="button-unbox-care-package"
          >
            <span className="chest-beam" />
            <span className="chest-lid" />
            <span className="chest-body" />
            <span className="chest-lock">♥</span>
          </button>
          {chestState === 'open' && (
            <div className="loot-note" role="status">
              <Sparkles size={14} /> Zizi's care drop: “My Cute Monster, you don't have to beat every level today. Rest, get cosy, and let Bablu keep watch. I'm cheering for you in Lahore and always.” 🌸
            </div>
          )}
        </section>
      </div>
      <Confetti trigger={confettiTrigger} />
    </>
  );
}
