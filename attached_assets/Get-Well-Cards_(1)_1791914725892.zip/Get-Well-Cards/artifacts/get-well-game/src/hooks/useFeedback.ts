import { useCallback } from 'react';

export function useFeedback(soundOn: boolean) {
  const tap = useCallback((frequency = 680) => {
    if (soundOn) {
      try {
        const AudioContextClass = window.AudioContext || (window as Window & { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
        if (AudioContextClass) {
          const context = new AudioContextClass();
          const oscillator = context.createOscillator();
          const gain = context.createGain();
          oscillator.type = 'sine';
          oscillator.frequency.setValueAtTime(frequency, context.currentTime);
          oscillator.frequency.exponentialRampToValueAtTime(frequency * 1.25, context.currentTime + 0.09);
          gain.gain.setValueAtTime(0.0001, context.currentTime);
          gain.gain.exponentialRampToValueAtTime(0.045, context.currentTime + 0.018);
          gain.gain.exponentialRampToValueAtTime(0.0001, context.currentTime + 0.17);
          oscillator.connect(gain);
          gain.connect(context.destination);
          oscillator.start();
          oscillator.stop(context.currentTime + 0.18);
          oscillator.onended = () => void context.close();
        }
      } catch {
        // Audio is optional and may be blocked until the visitor interacts.
      }
    }

    try {
      const reduceMotion = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
      if (!reduceMotion && typeof navigator !== 'undefined' && 'vibrate' in navigator) navigator.vibrate(12);
    } catch {
      // Haptics are an optional enhancement.
    }
  }, [soundOn]);

  const meow = useCallback(() => {
    if (!soundOn) return;
    try {
      const AudioContextClass = window.AudioContext || (window as Window & { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      if (!AudioContextClass) return;
      const context = new AudioContextClass();
      const oscillator = context.createOscillator();
      const gain = context.createGain();
      oscillator.type = 'triangle';
      oscillator.frequency.setValueAtTime(690, context.currentTime);
      oscillator.frequency.exponentialRampToValueAtTime(440, context.currentTime + 0.19);
      oscillator.frequency.exponentialRampToValueAtTime(590, context.currentTime + 0.34);
      gain.gain.setValueAtTime(0.0001, context.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.065, context.currentTime + 0.025);
      gain.gain.exponentialRampToValueAtTime(0.0001, context.currentTime + 0.4);
      oscillator.connect(gain);
      gain.connect(context.destination);
      oscillator.start();
      oscillator.stop(context.currentTime + 0.42);
      oscillator.onended = () => void context.close();
    } catch {
      return;
    }
  }, [soundOn]);

  return { tap, meow };
}
