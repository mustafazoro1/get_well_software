import { useState, type PointerEvent as ReactPointerEvent } from 'react';
import { Heart, Moon, Sun, Volume2, VolumeX } from 'lucide-react';
import './_upgrade.css';
import { CareKit } from './UpgradeCareKit';
import { Confetti } from './UpgradeConfetti';
import { Game } from './UpgradeGame';
import { SupportFeatures } from './UpgradeSupportFeatures';

function App() {
  const [soundOn, setSoundOn] = useState(true);
  const [darkMode, setDarkMode] = useState(false);
  const [confettiTrigger, setConfettiTrigger] = useState(0);

  const handleTilt = (event: ReactPointerEvent<HTMLElement>) => {
    const target = event.target as HTMLElement;
    if (event.pointerType === 'touch' || window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    const pointerX = event.clientX / window.innerWidth - 0.5;
    const pointerY = event.clientY / window.innerHeight - 0.5;
    event.currentTarget.style.setProperty('--parallax-x', `${(pointerX * -18).toFixed(1)}px`);
    event.currentTarget.style.setProperty('--parallax-y', `${(pointerY * -12).toFixed(1)}px`);
    if (target.closest('.game-arena')) return;
    const surface = target.closest<HTMLElement>('.tilt-surface');
    if (!surface) return;
    const bounds = surface.getBoundingClientRect();
    if (!bounds.width || !bounds.height) return;
    const x = (event.clientX - bounds.left) / bounds.width - 0.5;
    const y = (event.clientY - bounds.top) / bounds.height - 0.5;
    surface.style.setProperty('--tilt-x', `${(-y * 7).toFixed(2)}deg`);
    surface.style.setProperty('--tilt-y', `${(x * 7).toFixed(2)}deg`);
  };

  const resetTilt = (event: ReactPointerEvent<HTMLElement>) => {
    const target = event.target as HTMLElement;
    const nextTarget = event.relatedTarget instanceof Node ? event.relatedTarget : null;
    if (!nextTarget || !event.currentTarget.contains(nextTarget)) {
      event.currentTarget.style.setProperty('--parallax-x', '0px');
      event.currentTarget.style.setProperty('--parallax-y', '0px');
    }
    const surface = target.closest<HTMLElement>('.tilt-surface');
    const nextSurface = event.relatedTarget instanceof Element
      ? event.relatedTarget.closest<HTMLElement>('.tilt-surface')
      : null;
    if (surface && nextSurface !== surface) {
      surface.style.setProperty('--tilt-x', '0deg');
      surface.style.setProperty('--tilt-y', '0deg');
    }
  };

  return (
    <main className={`app-shell ${darkMode ? 'dark-mode' : ''}`} onPointerMove={handleTilt} onPointerOut={resetTilt}>
      <div className="floating-decor" aria-hidden="true">
        <span className="pixel-float pixel-heart">♥</span>
        <span className="pixel-float pixel-can" aria-hidden="true">M</span>
        <span className="pixel-float pixel-mm">MM2</span>
        <span className="pixel-float pixel-cloud">☁</span>
      </div>
      <header className="topbar">
        <div className="brand-mark">
          <span className="brand-orb"><Heart size={17} fill="currentColor" /></span>
          <span>zizi's care package</span>
        </div>
        <div className="top-actions">
          <button className="theme-toggle tilt-surface" onClick={() => setDarkMode((enabled) => !enabled)} aria-pressed={darkMode} data-testid="button-theme-toggle">
            {darkMode ? <Sun size={15} /> : <Moon size={15} />}
            {darkMode ? 'Soft mode' : 'Gamer mode'}
          </button>
          <button className="sound-toggle tilt-surface" onClick={() => setSoundOn((enabled) => !enabled)} aria-pressed={soundOn} data-testid="button-sound-toggle">
            {soundOn ? <Volume2 size={15} /> : <VolumeX size={15} />}
            Sound {soundOn ? 'on' : 'off'}
          </button>
        </div>
      </header>
      <section className="hero tilt-surface">
        <div className="eyebrow">A LITTLE LOVE, DELIVERED IN PIXELS</div>
        <h1>Get Well Soon, Cute Monster! 🌸 <span>Monster Energy &amp; Health Boost</span></h1>
        <p className="hero-copy">
          Sending warm hug vibes all the way to Lahore! 🏙️❤️ <strong>Take rest now so you can slay your tests next week! 📚✨</strong>
        </p>
        <div className="hero-meta">
          <span className="tag">🐱 Bablu-approved</span>
          <span className="tag">🎮 Roblox · MM2 &amp; Evade</span>
          <span className="tag">⛏️ Minecraft heart restore</span>
          <span className="tag">🥤 Gamer fuel, later</span>
        </div>
      </section>
      <div className="comfort-bar tilt-surface" role="note" data-testid="text-current-vibe">
        <span aria-hidden="true">🌡️</span>
        <div>Current Vibe in Lahore: Cold &amp; Fever 🤒 -&gt; Solution: Warm hugs from Zizi + Rest 🌸</div>
      </div>
      <div className="content-grid">
        <Game
          soundOn={soundOn}
          onConfetti={() => setConfettiTrigger((value) => value + 1)}
        />
      </div>
      <div className="content-grid">
        <CareKit soundOn={soundOn} />
      </div>
      <SupportFeatures soundOn={soundOn} />
      <div className="note-strip tilt-surface">
        <span>🌷</span>
        <div>Being a little under the weather is a side quest. Your only main mission today is to rest.</div>
      </div>
      <p className="footer-note">MADE WITH LOTS OF LOVE · FROM ZIZI TO CUTE MONSTER</p>
      <Confetti trigger={confettiTrigger} />
    </main>
  );
}

export default App;
