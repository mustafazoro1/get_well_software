import { useState } from 'react';
import { Heart, Volume2, VolumeX } from 'lucide-react';
import './_group.css';
import { CareKit } from './CareKit';
import { Confetti } from './Confetti';
import { Game } from './Game';

function App() {
  const [soundOn, setSoundOn] = useState(true);
  const [confettiTrigger, setConfettiTrigger] = useState(0);

  return (
    <main className="app-shell">
      <header className="topbar">
        <div className="brand-mark">
          <span className="brand-orb"><Heart size={17} fill="currentColor" /></span>
          <span>zizi's care package</span>
        </div>
        <button
          className="sound-toggle"
          onClick={() => setSoundOn((enabled) => !enabled)}
          aria-pressed={soundOn}
          data-testid="button-sound-toggle"
        >
          {soundOn ? <Volume2 size={15} /> : <VolumeX size={15} />}
          Sound {soundOn ? 'on' : 'off'}
        </button>
      </header>
      <section className="hero">
        <div className="eyebrow">A LITTLE LOVE, DELIVERED IN PIXELS</div>
        <h1>Get Well Soon, Cute Monster! 🌸 <span>Monster Energy &amp; Health Boost</span></h1>
        <p className="hero-copy">
          Sending warm hug vibes all the way to Lahore! 🏙️❤️ <strong>Take rest now so you can slay your tests next week! 📚✨</strong>
        </p>
        <div className="hero-meta">
          <span className="tag">🐱 Bablu-approved</span>
          <span className="tag">🎮 Roblox · MM2 &amp; Evade</span>
          <span className="tag">⛏️ Minecraft heart restore</span>
          <span className="tag">🥤 Gamer fuel, later</span>
        </div>
      </section>
      <div className="content-grid">
        <Game
          soundOn={soundOn}
          onConfetti={() => setConfettiTrigger((value) => value + 1)}
        />
        <CareKit soundOn={soundOn} />
      </div>
      <div className="note-strip">
        <span>🌷</span>
        <div>Being a little under the weather is a side quest. Your only main mission today is to rest.</div>
      </div>
      <p className="footer-note">MADE WITH LOTS OF LOVE · FROM ZIZI TO CUTE MONSTER</p>
      <Confetti trigger={confettiTrigger} />
    </main>
  );
}

export default App;
