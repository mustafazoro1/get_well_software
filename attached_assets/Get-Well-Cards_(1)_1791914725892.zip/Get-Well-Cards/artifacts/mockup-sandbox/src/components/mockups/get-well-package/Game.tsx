import { useCallback, useEffect, useRef, useState, type PointerEvent } from 'react';
import { Play, RotateCcw, Sparkles } from 'lucide-react';

type FallingItem = {
  id: number;
  x: number;
  y: number;
  icon: string;
  type: 'good' | 'hazard';
};

type GameProps = {
  soundOn: boolean;
  onConfetti: () => void;
};

const goodItems = [
  { icon: '🥤', points: 20, feedback: 'Monster Energy Health +20!' },
  { icon: '💕', points: 10, feedback: 'MM2 Victory Royale!' },
  { icon: '🍵', points: 15, feedback: 'Zizi is cheering for you!' },
  { icon: '🐱', points: 25, feedback: 'Bablu gives you a purr-fect hug!' },
];

export function Game({ soundOn, onConfetti }: GameProps) {
  const [items, setItems] = useState<FallingItem[]>([]);
  const [playing, setPlaying] = useState(false);
  const [score, setScore] = useState(0);
  const [lives, setLives] = useState(3);
  const [playerX, setPlayerX] = useState(50);
  const [feedback, setFeedback] = useState('');
  const [round, setRound] = useState(0);
  const arenaRef = useRef<HTMLDivElement>(null);
  const nextId = useRef(0);
  const scoreRef = useRef(0);
  const livesRef = useRef(3);
  const soundRef = useRef(soundOn);

  soundRef.current = soundOn;

  const playSound = useCallback((good: boolean) => {
    if (!soundRef.current) return;
    try {
      const AudioContextConstructor = window.AudioContext || (window as Window & { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      if (!AudioContextConstructor) return;
      const context = new AudioContextConstructor();
      const oscillator = context.createOscillator();
      const gain = context.createGain();
      oscillator.type = 'sine';
      oscillator.frequency.value = good ? 660 : 230;
      gain.gain.setValueAtTime(0.0001, context.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.075, context.currentTime + 0.025);
      gain.gain.exponentialRampToValueAtTime(0.0001, context.currentTime + 0.18);
      oscillator.connect(gain);
      gain.connect(context.destination);
      oscillator.start();
      oscillator.stop(context.currentTime + 0.19);
      oscillator.onended = () => void context.close();
    } catch {
      return;
    }
  }, []);

  const finishGame = useCallback(() => {
    setPlaying(false);
    setItems([]);
  }, []);

  const catchItem = useCallback((item: FallingItem) => {
    if (!playing) return;
    setItems((current) => current.filter((entry) => entry.id !== item.id));
    if (item.type === 'hazard') {
      playSound(false);
      setFeedback('Evade the fever cloud!');
      livesRef.current -= 1;
      setLives(livesRef.current);
      if (livesRef.current <= 0) finishGame();
      return;
    }
    const prize = goodItems.find((entry) => entry.icon === item.icon) ?? goodItems[0];
    scoreRef.current += prize.points;
    setScore(scoreRef.current);
    setFeedback(prize.feedback);
    playSound(true);
    if (scoreRef.current >= 100) {
      setFeedback('Zizi is cheering for you!');
      finishGame();
      onConfetti();
    }
  }, [finishGame, onConfetti, playSound, playing]);

  const startGame = () => {
    scoreRef.current = 0;
    livesRef.current = 3;
    setScore(0);
    setLives(3);
    setItems([]);
    setFeedback('');
    setPlayerX(50);
    setPlaying(true);
    setRound((value) => value + 1);
  };

  useEffect(() => {
    if (!playing) return;
    let spawnCounter = 0;
    const timer = window.setInterval(() => {
      spawnCounter += 1;
      setItems((current) => {
        const moved = current
          .map((item) => ({ ...item, y: item.y + (item.type === 'hazard' ? 2.4 : 2.15) }))
          .filter((item) => {
            if (item.y < 86) return true;
            if (item.type === 'hazard') livesRef.current = Math.max(0, livesRef.current - 1);
            return false;
          });
        if (spawnCounter % 12 === 0) {
          const isHazard = Math.random() < 0.25;
          const prize = goodItems[Math.floor(Math.random() * goodItems.length)];
          moved.push({
            id: nextId.current++,
            x: 9 + Math.random() * 82,
            y: -5,
            icon: isHazard ? '🤒' : prize.icon,
            type: isHazard ? 'hazard' : 'good',
          });
        }
        return moved;
      });
      setLives(livesRef.current);
      if (livesRef.current <= 0) finishGame();
    }, 80);
    return () => window.clearInterval(timer);
  }, [finishGame, playing, round]);

  useEffect(() => {
    if (!playing) return;
    const collisionTimer = window.setInterval(() => {
      const close = items.find((item) => item.y > 69 && item.y < 83 && Math.abs(item.x - playerX) < 11);
      if (close) catchItem(close);
    }, 90);
    return () => window.clearInterval(collisionTimer);
  }, [catchItem, items, playerX, playing]);

  const movePlayer = (event: PointerEvent<HTMLDivElement>) => {
    if (!playing || !arenaRef.current) return;
    const bounds = arenaRef.current.getBoundingClientRect();
    const position = ((event.clientX - bounds.left) / bounds.width) * 100;
    setPlayerX(Math.max(7, Math.min(93, position)));
  };

  const status = score >= 100 ? 'BOOST COMPLETE' : playing ? 'ROUND IN PROGRESS' : score > 0 ? 'ROUND PAUSED' : 'READY WHEN YOU ARE';

  return (
    <section className="panel game-panel" aria-labelledby="game-title">
      <div className="section-heading">
        <div>
          <div className="eyebrow"><Sparkles size={12} /> MINI GAME · EVADE MODE</div>
          <h2 id="game-title">Evade the Fever &amp; Catch the Monster Energy</h2>
          <p>Drag your little pink catcher. Grab the good stuff, dodge the fever clouds.</p>
        </div>
        <div className="score-pill" data-testid="status-game-score">
          <small>Score</small>
          <strong>{score}</strong>
        </div>
      </div>
      <div
        className="game-arena"
        ref={arenaRef}
        onPointerMove={movePlayer}
        onPointerDown={(event) => {
          movePlayer(event);
          if (event.pointerType !== 'mouse') event.currentTarget.setPointerCapture(event.pointerId);
        }}
        aria-label="Game arena. Move your finger to catch falling treats and avoid clouds."
        data-testid="game-arena"
      >
        <div className="arena-hud">
          <span>{status}</span>
          <span>♥ {playing ? lives : 3} / 3</span>
        </div>
        {items.map((item) => (
          <button
            key={item.id}
            className={`game-item ${item.type === 'hazard' ? 'hazard' : ''}`}
            style={{ left: `${item.x}%`, top: `${item.y}%` }}
            aria-label={item.type === 'hazard' ? 'Fever cloud, avoid' : `Catch ${item.icon}`}
            data-testid={`game-item-${item.id}`}
            onPointerDown={(event) => {
              event.stopPropagation();
              catchItem(item);
            }}
          >
            {item.icon}
          </button>
        ))}
        {playing && <div className="player" style={{ left: `${playerX}%` }} aria-hidden="true">🐸</div>}
        {feedback && <div key={feedback} className="float-feedback" aria-live="polite">{feedback}</div>}
        {!playing && (
          <div className="arena-start">
            <div className="big-emoji">{score >= 100 ? '🏆' : score > 0 && lives <= 0 ? '🌤️' : '🎮'}</div>
            <strong>{score >= 100 ? 'You powered through!' : score > 0 && lives <= 0 ? 'Fever cloud got you!' : 'Ready, Cute Monster?'}</strong>
            <span>{score >= 100 ? '100 health points collected. Rest is your next level.' : 'Collect 100 points to win. Three fever clouds and the round is over.'}</span>
          </div>
        )}
      </div>
      <div className="game-controls">
        <span className="control-hint">Catch 🥤 +20 · 💕 +10 · 🍵 +15 · 🐱 +25<br />Avoid 🤒 clouds · {lives} hearts left</span>
        <button className="primary-button" onClick={startGame} data-testid="button-start-game">
          {score > 0 || lives < 3 ? <RotateCcw size={16} /> : <Play size={16} />}
          {playing ? 'Restart round' : score >= 100 ? 'Play again' : 'Start game'}
        </button>
      </div>
    </section>
  );
}
