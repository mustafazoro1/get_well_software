import { useEffect, useState } from 'react';
import { Check, ChevronRight, X } from 'lucide-react';
import { Confetti } from './UpgradeConfetti';
import { useFeedback } from './useFeedback';

type ModalKind = 'potion' | 'shield' | 'rest' | 'note' | null;

const tasks = [
  'Took medicines 💊',
  'Drank warm soup/tea 🍵',
  'Hugged Bablu (or thought about Bablu) 🐱',
  'Took a nap for test prep 💤',
];

type CareKitProps = {
  soundOn: boolean;
};

function todayStorageKey() {
  const today = new Date();
  const localDate = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;
  return `cute-monster-care-${localDate}`;
}

export function CareKit({ soundOn }: CareKitProps) {
  const { tap } = useFeedback(soundOn);
  const [modal, setModal] = useState<ModalKind>(null);
  const [completed, setCompleted] = useState<boolean[]>(() => {
    try {
      const stored = localStorage.getItem(todayStorageKey());
      const parsed = stored ? JSON.parse(stored) as boolean[] : [];
      return tasks.map((_, index) => Boolean(parsed[index]));
    } catch {
      return tasks.map(() => false);
    }
  });
  const [confettiTrigger, setConfettiTrigger] = useState(0);

  useEffect(() => {
    try {
      localStorage.setItem(todayStorageKey(), JSON.stringify(completed));
    } catch {
      return;
    }
  }, [completed]);

  const toggleTask = (index: number) => {
    const next = completed.map((checked, taskIndex) => taskIndex === index ? !checked : checked);
    setCompleted(next);
    if (!completed[index]) tap(740);
    if (next.every(Boolean) && !completed.every(Boolean)) setConfettiTrigger((value) => value + 1);
  };

  const completeCount = completed.filter(Boolean).length;
  const content = {
    potion: {
      icon: '🧪',
      title: 'Monster Energy Health Potion',
      text: 'Tiny healer reminder: while you are sick, choose warm water or a cosy cup of tea instead of cold drinks. Save the Monster Energy for when you are feeling well again, Cute Monster.',
      quote: 'Warm sips, soft blankets, and a little patience. Your health bar comes first.',
    },
    shield: {
      icon: '🛡️',
      title: 'MM2 / Evade Emergency Shield',
      text: 'Shield activated. You do not have to speedrun getting better. Take the rest your body asks for, then return to Roblox (MM2 & Evade) and Minecraft when you feel ready.',
      quote: '“The bravest move is knowing when to pause, heal, and rejoin the game.”',
    },
    rest: {
      icon: '🍎',
      title: 'Minecraft Golden Apple Rest Check',
      text: 'A tiny daily quest for your real-life health bar. Tap each task as you do it today.',
      quote: '',
    },
    note: {
      icon: '💌',
      title: 'A note from Zizi',
      text: 'My dear Cute Monster, I am sending warm hug vibes all the way to Lahore! 🏙️❤️ Please rest, drink something warm, and let Bablu keep you company. You have the strength to take on your exams next week, one calm step at a time. You do not need to study every minute to prove how capable you are. Get well soon, my favourite gamer girl. I am cheering for you, always.',
      quote: 'Take rest now so you can slay your tests next week! 📚✨',
    },
  };
  const active = modal ? content[modal] : null;

  return (
    <>
      <section className="panel care-panel tilt-surface" aria-labelledby="care-title">
        <div className="care-head">
          <div>
            <div className="eyebrow">YOUR LITTLE POWER-UP</div>
            <h2 id="care-title">Cute Monster Care Kit</h2>
            <p>Choose a boost. Small quests count.</p>
          </div>
          <span className="care-badge">DAILY QUEST</span>
        </div>
        <div className="care-buttons">
          <button className="care-button tilt-surface" onClick={() => setModal('potion')} data-testid="button-open-potion">
            <span className="button-icon">🧪</span>
            <span className="button-label">
              <strong>Monster Energy Health Potion</strong>
              <small>A warm-drink reminder</small>
            </span>
            <ChevronRight size={17} />
          </button>
          <button className="care-button tilt-surface" onClick={() => setModal('shield')} data-testid="button-open-shield">
            <span className="button-icon">🛡️</span>
            <span className="button-label">
              <strong>MM2 / Evade Emergency Shield</strong>
              <small>Activate your gamer pep talk</small>
            </span>
            <ChevronRight size={17} />
          </button>
          <button className="care-button tilt-surface" onClick={() => setModal('rest')} data-testid="button-open-rest-check">
            <span className="button-icon">🍎</span>
            <span className="button-label">
              <strong>Minecraft Golden Apple Rest Check</strong>
              <small>{completeCount}/4 real-life hearts restored</small>
            </span>
            <ChevronRight size={17} />
          </button>
          <button className="care-button tilt-surface" onClick={() => setModal('note')} data-testid="button-open-note">
            <span className="button-icon">💌</span>
            <span className="button-label">
              <strong>Message from Zizi</strong>
              <small>A hug in note form, from Lahore's faraway friend</small>
            </span>
            <ChevronRight size={17} />
          </button>
        </div>
        <div className="daily-progress">
          <div className="progress-line">
            <span>Golden apple progress</span>
            <span>{completeCount} / 4</span>
          </div>
          <div className="progress-track" aria-label={`${completeCount} of 4 care tasks complete`}>
            <div className="progress-fill" style={{ width: `${(completeCount / 4) * 100}%` }} />
          </div>
          <div className="check-list">
            {tasks.map((task, index) => (
              <button
                key={task}
                className={`check-task tilt-surface ${completed[index] ? 'checked' : ''}`}
                onClick={() => toggleTask(index)}
                aria-pressed={completed[index]}
                data-testid={`button-task-${index + 1}`}
              >
                <span className="checkbox">{completed[index] && <Check size={14} />}</span>
                <span>{task}</span>
              </button>
            ))}
          </div>
        </div>
      </section>
      <Confetti trigger={confettiTrigger} />
      {active && (
        <div
          className="modal-backdrop"
          role="presentation"
          onMouseDown={(event) => {
            if (event.target === event.currentTarget) setModal(null);
          }}
        >
            <section className="modal-card tilt-surface" role="dialog" aria-modal="true" aria-labelledby="modal-title" data-testid={`modal-${modal}`}>
            <div className="modal-top">
              <span className="modal-icon">{active.icon}</span>
              <button className="close-button tilt-surface" aria-label="Close" onClick={() => setModal(null)} data-testid="button-close-modal">
                <X size={19} />
              </button>
            </div>
            <h2 id="modal-title">{active.title}</h2>
            <p>{active.text}</p>
            {modal === 'rest' && (
              <>
                <div className="progress-track" style={{ marginTop: 16 }}>
                  <div className="progress-fill" style={{ width: `${(completeCount / 4) * 100}%` }} />
                </div>
                <div className="check-list">
                  {tasks.map((task, index) => (
                    <button
                      key={task}
                      className={`check-task tilt-surface ${completed[index] ? 'checked' : ''}`}
                      onClick={() => toggleTask(index)}
                      aria-pressed={completed[index]}
                      data-testid={`modal-task-${index + 1}`}
                    >
                      <span className="checkbox">{completed[index] && <Check size={14} />}</span>
                      <span>{task}</span>
                    </button>
                  ))}
                </div>
                {completeCount === 4 && <div className="modal-quote">Quest complete! Full hearts for our Cute Monster. 🍎</div>}
              </>
            )}
            {active.quote && <div className="modal-quote">{active.quote}</div>}
            {modal === 'note' && <div className="modal-signoff">ALWAYS IN YOUR CORNER · ZIZI ✿</div>}
          </section>
        </div>
      )}
    </>
  );
}
